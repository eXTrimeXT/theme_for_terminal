# clear history in .bash_history
# очистка истории в BASH
path = ".bash_history"
file_history = open(path, "w")

Hi_text = """##########################
### Hello from eXTrime ###
##########################\n"""

file_history.write(Hi_text)
file_history.close()